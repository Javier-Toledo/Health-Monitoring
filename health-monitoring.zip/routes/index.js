const express = require('express');
const { acessControl } = require('../middlewares/accessControl');

const router = express.Router();

// importar archivos de rutas
const usersRoutes = require('./usersRoutes');
const patientRoutes = require('./patientRoutes');

module.exports = () => {

  // vincular router de cada archivo de rutas
  usersRoutes(router, acessControl);
  patientRoutes(router, acessControl);
  
  return router;
}
