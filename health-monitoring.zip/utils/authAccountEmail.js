require('dotenv').config();
const nodemailer = require ('nodemailer');

const servidor_smtp = process.env.SERVIDOR_SMPT;
const usuario_smpt = process.env.USUARIO_SMPT;
const password_smpt = process.env.PASSWORD_SMPT;

exports.authAccountEmail = async (nombre, email, token) => {
    try {
        let transporter = nodemailer.createTransport({
            host: servidor_smtp,
            port: 587,
            secure: false, // true for 465, false for other ports
            auth: {
              user: usuario_smpt, // generated ethereal user
              pass: password_smpt, // generated ethereal password
            },
        });
        
        let mensaje = `Hello ${nombre} <br>`;
            mensaje += 'We need to authenticate your account, ';
            mensaje += ` <a href="http://localhost:5000/validate-token-account/${token}"> Click here </a> <br> `;
            mensaje += 'The link is valid only for one hour from its submission.';

        let info = await transporter.sendMail({
            from: '"Health-Monitoring 👻" <toledo_javier@outlook.com>', // sender address
            to: `${nombre} <${email}>`, // list of receivers
            subject: "Authenticate account", // Subject line
            //text: "Hello world?", // plain text body
            html: mensaje, // html body
        });
        
        console.log("Message sent: %s", info.messageId);

        return true;
    } catch (error) {
        console.log(error);
        return false;
    }
};